<!-- Home -->
<?php include"modals(login_registrasi).php"; ?>
        <div class=" col-2" id="collapsibleNavbar">
            <ul class=" nav list-group list-group-flush">
                <a href="<?php echo base_url(); ?>repository/page/" class="list-group-item list-group-item-action list-group-item py-0" style="font-family: Andalus"><strong>Home</strong></a>
                <a href="<?php echo base_url(); ?>repository/page/about" class="list-group-item list-group-item-action list-group-item py-0" style="font-family: Andalus"><strong>About</strong></a>
                <a href="<?php echo base_url(); ?>repository/page/faq" class="list-group-item list-group-item-action list-group-item py-0" style="font-family: Andalus"><strong>FAQ</strong></a>
            </ul> <br>
            <ul class=" nav list-group ">
                <li class="list-group-item list-group-item-success list-group-item py-1"  style="font-family: Andalus"><strong>Account</strong></li>
                <a  data-toggle="modal" data-target="#login" class="list-group-item list-group-item-action list-group-item py-0" style="font-family: Andalus" >Login</a>
                <a  data-toggle="modal" data-target="#registrasi" class="list-group-item list-group-item-action list-group-item py-0" style="font-family: Andalus">Registrasi</a>
            </ul> <br>
            <ul class=" nav list-group ">
                <li class="list-group-item list-group-item-success list-group-item py-1" style="font-family: Andalus"><strong>Browse</strong></li>
                <a href="#" class="list-group-item list-group-item-action list-group-item py-0"  style="font-family: Andalus">By Issue Date</a>
                <a href="#" class="list-group-item list-group-item-action list-group-item py-0"  style="font-family: Andalus">Titles</a>
                <a href="#" class="list-group-item list-group-item-action list-group-item py-0"  style="font-family: Andalus">Authors</a>
                <a href="#" class="list-group-item list-group-item-action list-group-item py-0"  style="font-family: Andalus">Advisors</a>
                <a href="#" class="list-group-item list-group-item-action list-group-item py-0"  style="font-family: Andalus">Keywords</a>
                <a href="#" class="list-group-item list-group-item-action list-group-item py-0"  style="font-family: Andalus">Types</a>
                <a href="#" class="list-group-item list-group-item-action list-group-item py-0" style="font-family: Andalus" >By Submit Date</a>
            </ul> <br>
        </div>
        <div class=" col-1"> &nbsp; </div>
