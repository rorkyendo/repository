<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="modal fade" id="login">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <!-- Modal Header -->
        <div class="modal-header">
          <h5 class="modal-title" style="text-align: center;">Login</h5>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          

        </div>        <!-- Modal body -->
        <div class="modal-body">
           <ul class="nav nav-tabs">
            <li class="nav-item">
              <a class="nav-link active" data-toggle="tab" href="#MahasiswaDosen">Mahasiswa/Dosen</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="tab" href="#PenggunaBaru">Guest</a>
            </li>
          </ul><br>
          <div class="tab-content">
                <div id="MahasiswaDosen" class="container tab-pane active">
                <form action="<?php echo base_url()?>auth/login" method="post">
                  <?php echo $this->session->flashdata('notif'); ?>
                  <div class="form-group">
                    <label>NIM/NIP</label>
                    <input type="text" name="identity" class="form-control" placeholder="Enter NIM/NIP">
                  </div>
                  <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Enter Password">
                  </div>
                  <div class="modal-footer">
                  <button type="submit" class="btn btn-info" >Submit</button>
                </div>
                </form>
               </div>

               <div id="PenggunaBaru" class="container tab-pane fade">
                <form action="<?php echo base_url()?>auth/login" method="post">
                  <?php echo $this->session->flashdata('notif'); ?>
                  <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="identity" class="form-control" placeholder="Enter NIM/NIP">
                  </div>
                  <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Enter Password">
                  </div>
                  <div class="modal-footer">
                  <button type="submit" class="btn btn-info" >Submit</button>
                  </div>
                </form>
               </div>
          </div>
        </div>
      </div>
    </div>
  </div>


  <div class="modal fade" id="registrasi">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Registrasi</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>        <!-- Modal body -->
        <div class="modal-body">
         
          <div class="alert alert-info">
  Untuk Dosen/Mahasiswa Fasilkom-TI dapat melakukan login langsung dari <button type="button" class="btn btn-info btn-sm" data-dismiss="modal" data-target="#login" data-toggle="modal"><strong>sini</strong></button>
</div>
<form action="<?php echo base_url()?>auth/register" method="post" id="registrasi">
  <div class="form-group">
    <label>NIK</label>
    <input type="text" name="nik" class="form-control" placeholder="Masukkan NIK" pattern="[0-9]" maxlength="18" minlength="14" title="Masukkan data sesuai nik" required>
  </div>
  <div class="form-group">
    <label>Username</label>
    <input type="text" name="username" class="form-control" placeholder="Masukkan username" minlength="3" title="Masukkan username" required>
  </div>
  <div class="form-group">
    <label>Password</label> &nbsp;

     <div class="input-group">
      <input type="password" name="password" class="form-control" placeholder="Masukkan Password" id="pass" title="Masukkan password" required>
      <div class="input-group-append">
        <button class="btn btn-light btn-md" type="button" id="lock" title="click untuk melihat password"><i class="fa fa-eye"></i></button>
        <button class="btn btn-secondary btn-md" hidden type="button" id="unlock" title="click untuk menyembunyikan password"><i class="fa fa-eye"></i></button>
      </div>
      </div> 
  </div>
  <div class="form-group">
    <label>Nama Depan</label>
    <input type="text" name="nama_depan" class="form-control" placeholder="Masukkan nama depan" pattern="[a-zA-Z ]" minlength="3" title="Masukkan nama depan" required>
  </div>
  <div class="form-group">
    <label>Nama Belakang</label>
    <input type="text" name="nama_belakang" class="form-control" placeholder="Masukkan nama belakang" pattern="[a-zA-Z ]" minlength="3" title="Masukkan nama belakang" required>
  </div>
  <div class="form-group">
    <label>Jenis Kelamin</label>
    <select class="form-control" name="jenkel" title="Pilih jenis kelamin" required>
      <option>-Pilih Jenis Kelamin-</option>
      <option value="L">Laki-laki</option>
      <option value="P">Perempuan</option>
    </select>
  </div>
  <div class="form-group">
    <label>Email</label>
    <input type="email" name="email" class="form-control" placeholder="Masukkan email" title="Masukkan email" required>
  </div>
  <div class="form-group">
    <label>No HP</label>
    <input type="text" name="nomor_hp" class="form-control" pattern="[0-9]" placeholder="Masukkan nomor handphone" title="Masukkan nomor handphone" required>
  </div>
  <div class="form-group">
    <label>Tempat Lahir</label>
    <input type="text" name="tempat_lahir" class="form-control" placeholder="Masukkan nama tempat lahir" pattern="[a-zA-Z ]" minlength="3" title="Masukkan tempat lahir" required>
  </div>
  <div class="form-group">
    <label>Tanggal Lahir</label>
    <input type="text" id="datemask" placeholder="Masukkan tanggal lahir" name="tgl_lahir" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask title="Masukkan tanggal lahir" required>
  </div>

<script type="text/javascript">
  $("form#registrasi").validate({
    lang: 'id',
  });
  $('#lock').click(function(){
    $('#lock').attr('hidden',true);
    $('#unlock').removeAttr('hidden');
    $('#pass').prop('type','text');
  });
  $('#unlock').click(function(){
    $('#lock').removeAttr('hidden');
    $('#unlock').attr('hidden',true);
    $('#pass').prop('type','password');
  });
</script>

<script type="text/javascript">
  $(function(){
    //Date picker
       $('#datepicker').datepicker({
         autoclose: true
       });

       //Datemask dd/mm/yyyy
$('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
  })
</script>




        </div>
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="submit" class="btn btn-info" >Submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  

