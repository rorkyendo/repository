<!-- Footer -->
</div>
</div>
</div>
<footer class="footer">
	<div class="container">
	<div class="row footer_row">
		<div class="col">
		<div class="footer_content">
			<div class="row">
				<div class="col-lg-3 footer_col">
<!-- Footer About -->
					<div class="footer_section footer_about">
						<div class="footer_logo_container">
							<a href="">
								<div class="footer_logo_text" style="font-size: 26px;
	font-weight: 500;"><b>Fasilkom-TI</b></div>
							</a>
						</div>
					<div class="footer_about_text">
						<p></p>
					</div>
					<div class="footer_social">
						<ul>
							<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
					<div class="col-lg-3 footer_col">
								<!-- Footer Contact -->
								<div class="footer_section footer_contact">
									<div class="footer_title">Contact Us</div>
									<div class="footer_contact_info">
										<ul>
											<li style="font-size:15px; font-family: arial black;"> fasilkomti@usu.ac.id</li>
											<li  style="font-size:15px;font-family: arial black;" > +62 61 8222129</li>
											<li  style="font-size:15px; font-family: arial black;">Jl. Universitas No. 9A
Kampus USU, Medan 20155</li>
										</ul>
									</div>
								</div>
							</div>
							<div class="col-lg-3 footer_col clearfix">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row copyright_row">
				<div class="col">
					<div class="copyright d-flex flex-lg-row flex-column align-items-center justify-content-start">
						<div class="cr_text">
							Copyright &copy; 2018 Fakultas Ilmu Komputer dan Teknologi Informasi USU
					</div>
				</div>
			</div>
		</div>
	</footer>
</div>
<!-- InputMask -->
<script src="<?php echo base_url();?>assets/styles/plugins/greensock/TweenMax.min.js"></script>
<script src="<?php echo base_url();?>assets/styles/plugins/greensock/TimelineMax.min.js"></script>
<script src="<?php echo base_url();?>assets/styles/plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="<?php echo base_url();?>assets/styles/plugins/greensock/animation.gsap.min.js"></script>
<script src="<?php echo base_url();?>assets/styles/plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="<?php echo base_url();?>assets/styles/plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="<?php echo base_url();?>assets/styles/plugins/easing/easing.js"></script>
<script src="<?php echo base_url();?>assets/styles/plugins/parallax-js-master/parallax.min.js"></script>
<script src="<?php echo base_url();?>assets/styles/js/custom.js"></script>
