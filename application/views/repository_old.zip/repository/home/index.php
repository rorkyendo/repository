<div class=" col-9" id="collapsibleNavbar" > 
             <div class="input-group">
                <input type="text" class="form-control" placeholder="Search ...">
                <div class="input-group-append">
                  <button class="btn btn-secondary" type="button">
                    <i class="fa fa-search"></i>
                  </button>
                </div>
              </div> 
              <div class="row"> &nbsp; </div>
              <div class="row"> &nbsp; </div>
              <div class="row"> 
                <h2 style="font-family :Arial ;font-size:20px;"><b> Recently Added </b></h2>
              </div><br>
              <div class="list-group list-group-flush">
                <a href="#" class="list-group-item list-group-item-action list-group-item py-0"  style="font-family: Andalus"><br>
                  <h4>Judul jurnal</h4>
                  <p><i>Penulis (Tahun terbit)</i><br>Apa pendapatmu tentang ikhlas? Bagaimana hakikat ikhlas sebenarnya? Ditulis oleh penulis profesional
                  yang karyanya telah dikagumi dunia </p>
                </a>
                <a href="#" class="list-group-item list-group-item-action list-group-item py-0"  style="font-family: Andalus"><br>
                  <h4>Judul jurnal</h4>
                  <p><i>Penulis (Tahun terbit)</i><br>Apa pendapatmu tentang ikhlas? Bagaimana hakikat ikhlas sebenarnya? Ditulis oleh penulis profesional
                  yang karyanya telah dikagumi dunia </p>
                </a>
                <a href="#" class="list-group-item list-group-item-action list-group-item py-0"  style="font-family: Andalus"><br>
                  <h4>Judul jurnal</h4>
                  <p><i>Penulis (Tahun terbit)</i><br>Apa pendapatmu tentang ikhlas? Bagaimana hakikat ikhlas sebenarnya? Ditulis oleh penulis profesional
                  yang karyanya telah dikagumi dunia </p>
                </a>
              <a href="#" class="list-group-item list-group-item-action list-group-item py-0"  style="font-family: Andalus"><br>
                  <h4>Judul jurnal</h4>
                  <p><i>Penulis (Tahun terbit)</i><br>Apa pendapatmu tentang ikhlas? Bagaimana hakikat ikhlas sebenarnya? Ditulis oleh penulis profesional
                  yang karyanya telah dikagumi dunia </p>
                </a>
              </div><br>
        </div>

      </div>
 <br><br><br><br><br>


