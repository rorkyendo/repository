<!-- Header Content -->
<div class="super_container">
<!-- Header -->
   <header class="header">
      <!-- Top Bar -->

               
      <nav class="navbar navbar-expand-sm bg-light navbar-light " style="background-color: white">
               <div class="header_container">
                  <div class="logo_container">
                  <a href="#">
                  <div class="logo_text"><img src="<?php echo base_url()?>assets/img/logo_Fasilkom-TI.png"  alt="USU"  ></div>
                  </a>
               </div>
            </div>
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      

      <!-- Navbar links -->
      <div>
          <ul class="navbar-nav">
              <li class="nav-item" ><img src="<?php echo base_url()?>assets/img/rep.png"  alt="USU"  > </div></li>
          </ul>
      </div>

</div>
  </nav>

   

   </header>
   
</div>

   <!-- Menu -->

   <div class="menu d-flex flex-column align-items-end justify-content-start text-right menu_mm trans_400">
      <div class="menu_close_container"><div class="menu_close"><div></div><div></div></div></div>
      <div class="search">
         <form action="#" class="header_search_form menu_mm">
            <input type="search" class="search_input menu_mm" placeholder="Search" required="required">
            <button class="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">
               <i class="fa fa-search menu_mm" aria-hidden="true"></i>
            </button>
         </form>
      </div>
      
   </div>

   <div class="home">
        <div class="home_slider_background" style="background-color: white">
        </div>
       <div class="jumbotron" style="height: 200px; background-color: #1e2434; font-family: 'Roboto Slab',serif;font-size: 24px; margin-top: 40px"><font color="white"><center><b>Selamat Datang di Repositori <br> Fakultas Ilmu Komputer dan Teknologi Informasi <br> Universitas Sumatera Utara</b></center></font></div>
          <div class="container">
       <div class="row">
